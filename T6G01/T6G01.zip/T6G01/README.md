# MIEIC_SOPE_PROJ_2
Second Project of the Course SOPE @FEUP
